AI component for dot workspace

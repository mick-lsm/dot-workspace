function n(e) {
}
function a(e) {
}
const i = { enable: n, disable: a };
export {
  i as default
};

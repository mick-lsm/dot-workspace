Serp APIs component for dotWorkspace
